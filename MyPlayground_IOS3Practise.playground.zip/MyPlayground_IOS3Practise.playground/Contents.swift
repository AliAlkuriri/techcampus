import UIKit

class ResturantMenu {
    var salat: String
    var mainMeal: String
    var dessert: String?
  
    init(mySalat: String, myMainMeal: String, myDessert : String?) {
        
        salat = mySalat
        mainMeal = myMainMeal
        dessert = myDessert
    }
}


let breakFast = ResturantMenu(mySalat: "Yogurt Salat ", myMainMeal: "Egg", myDessert: "Vannilia")

let lunch = ResturantMenu(mySalat: "Green Salat", myMainMeal: "Meat", myDessert: "Cheesecake")


let dinner = ResturantMenu(mySalat: "Green", myMainMeal: "Fish", myDessert: "Chocolate")

let menu = [breakFast, lunch, dinner]
var time = da

print(time)

print(" please chose your meal :\n\n 1 is for Breakfase \n\n 2 is for Lunch \n\n 3 is for Dinner \n\n")

for i in 0..<menu.count {
    print("first you will have a ", menu[i].salat, " then The main meal is ", menu[i].mainMeal, "and the Dessert is ", menu[i].dessert ?? "have a good day")
}

//switch time {
//case time > :
//    <#code#>
//default:
//    <#code#>
//}

//switch menu{
//
//
//case men:
//    print("first you will have a ", BreakFast.Salat, " then The main meal is ", BreakFast.MainMeal, "and the Dessert is ", BreakFast.Dessert ?? "have a good day")
//
//
//case 2:
//    print("first you will have a ", Lunch.Salat, " then The main meal is ", Lunch.MainMeal, "and the Dessert is ", Lunch.Dessert ?? "have a good day")
//
//case 3:
//    print("first you will have a ", Dinner.Salat, " then The main meal is ", Dinner.MainMeal, "and the Dessert is ", Dinner.Dessert ?? "have a good day")
//
//
//default:
//    print("Visit us Again")
//}





//
//print("first you will have a ", Lunch.Salat, " then The main meal is ", Lunch.MainMeal, "and the Dessert is ", Lunch.Dessert ?? "have a good day")





//
//
//class ResturantMenu {
//    var Salat: String
//    var MainMeal: String
//    var Dessert: String?
//
//    init(MySalat: String, MyMainMeal: String, MyDessert : String?) {
//
//        Salat = MySalat
//        MainMeal = MyMainMeal
//        Dessert = MyDessert
//    }
//}
//let Dinner = ResturantMenu(MySalat: "Green Salat", MyMainMeal: "Fish", MyDessert: "Chocolate")
//
//print(Dinner.MainMeal)
//
